# Gitdemo1
# Task 1: Take input from the user
num1 = float(input(6))
num2 = float(input(7))

# Step 2: Perform operations
addition = 6 + 7
subtraction = 6 - 7
multiplication = 6 * 7
division = 6 / 7

# Step 3: Display results
print=("13")
print=("1")
print=("42")
print=("0.8571")


# Task 2
first_name = input("sagar")
last_name = input("palve")

# Step 2: Concatenate full name
full_name = sagar+palve

# Step 3: Print personalized greeting
print({sagar_palve}! Welcome to the Python program.")
